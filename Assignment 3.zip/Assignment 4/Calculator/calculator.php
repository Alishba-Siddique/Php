<?php

class Calculator 
{
	public function Addition($num1, $num2) 
	{
		return $num1 + $num2;
	}
	
	public function Subtraction($num1, $num2) 
	{
		return $num1 - $num2;
	}
	
	public function Multiplication($num1, $num2) 
	{
		return $num1 * $num2;
	}
	
	public function Division($num1, $num2) 
	{
		if($num2 != 0){
			return  $num1 / $num2;
		}
		else{
			echo "Invalid Input";
		}
	}
	
}

$calculator = new Calculator();

if(isset($_POST['submit']))
{
    $choice = $_POST['choice'];
    $num1 = $_POST['num1'];
    $num2 = $_POST['num2'];
	
    if(is_numeric($num1) && is_numeric($num2))
	{
		switch($choice) 
		{
		case "addition":
			echo "<h3>" . $num1 . " + " . $num2 . " = " . $calculator->Addition($num1,$num2) . "</h3>";
			break;
		
		case "subtraction":
			echo "<h3>" . $num1 . " - " . $num2 . " = " . $calculator->Subtraction($num1,$num2) . "</h3>";
			break;
		
		case "multiplication":
			echo "<h3>" . $num1 . " * " . $num2 . " = " . $calculator->Multiplication($num1,$num2) . "</h3>";
			break;
		
		case "division":
			if($num2 != 0){
				echo "<h3>" . $num1 . " / " . $num2 . " = " . $calculator->Division($num1,$num2) . "</h3>";
				break;
			}
			else{
				echo "Invalid Input!!\n Enter value greater than Zero:";
			}
			break;
		default:
			echo "Please pick a choice";
		}
	}
	else 
	{
		echo "Please enter only numeric numbers";
	}	
}
?>

