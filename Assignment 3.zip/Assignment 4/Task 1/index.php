<?php
class Persons {
  public $name;
  public $age;
  public function __construct($name, $age) {
    $this->name = $name;
    $this->age = $age;
  }
  protected function intro() {
    echo "I am {$this->name} and my age is {$this->age}.";
  }
}

class Users extends Persons {
  public function message() {
    $this -> intro();
  }
}

$User = new Users("Ali", "32"); 
$User->message();
?>